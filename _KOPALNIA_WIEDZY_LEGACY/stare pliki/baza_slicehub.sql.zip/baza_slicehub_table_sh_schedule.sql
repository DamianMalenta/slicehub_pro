
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_schedule`
--
-- Creation: Mar 26, 2026 at 09:05 PM
--

CREATE TABLE `sh_schedule` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shift_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_schedule`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `user_id`
--       `sh_users` -> `id`
--
