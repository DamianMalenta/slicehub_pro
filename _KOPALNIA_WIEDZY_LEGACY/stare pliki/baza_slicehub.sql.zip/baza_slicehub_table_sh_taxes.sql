
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_taxes`
--
-- Creation: Mar 31, 2026 at 05:55 AM
-- Ostatnia aktualizacja: Mar 31, 2026 at 05:55 AM
--

CREATE TABLE `sh_taxes` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `rate` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_taxes`:
--

--
-- Zrzut danych tabeli `sh_taxes`
--

INSERT INTO `sh_taxes` (`id`, `name`, `rate`) VALUES
(1, 'VAT 5%', 5.00),
(2, 'VAT 8%', 8.00),
(3, 'VAT 23%', 23.00),
(4, 'VAT 0%', 0.00);
