
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_finance_requests`
--
-- Creation: Mar 26, 2026 at 08:19 PM
--

CREATE TABLE `sh_finance_requests` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `target_user_id` int(11) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `type` varchar(50) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_paid_cash` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_finance_requests`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `target_user_id`
--       `sh_users` -> `id`
--   `created_by_id`
--       `sh_users` -> `id`
--
