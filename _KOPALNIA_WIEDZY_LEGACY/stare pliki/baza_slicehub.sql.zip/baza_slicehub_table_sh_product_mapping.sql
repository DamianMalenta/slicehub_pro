
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_product_mapping`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 26, 2026 at 10:53 PM
--

CREATE TABLE `sh_product_mapping` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `external_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nazwa z faktury dostawcy'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_product_mapping`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `product_id`
--       `sh_products` -> `id`
--

--
-- Zrzut danych tabeli `sh_product_mapping`
--

INSERT INTO `sh_product_mapping` (`id`, `tenant_id`, `product_id`, `external_name`) VALUES
(1, 1, 3, 'PULPA');
