
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_menu_tags`
--
-- Creation: Mar 31, 2026 at 07:53 AM
--

CREATE TABLE `sh_menu_tags` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `icon` varchar(50) DEFAULT 'fa-tag',
  `color` varchar(20) DEFAULT '#ffffff'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACJE DLA TABELI `sh_menu_tags`:
--
