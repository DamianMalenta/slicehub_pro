
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_modifier_groups`
--
-- Creation: Mar 31, 2026 at 03:38 AM
-- Ostatnia aktualizacja: Mar 31, 2026 at 04:00 AM
--

CREATE TABLE `sh_modifier_groups` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `min_selection` int(11) NOT NULL DEFAULT 0,
  `max_selection` int(11) NOT NULL DEFAULT 10,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACJE DLA TABELI `sh_modifier_groups`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--

--
-- Zrzut danych tabeli `sh_modifier_groups`
--

INSERT INTO `sh_modifier_groups` (`id`, `tenant_id`, `name`, `min_selection`, `max_selection`, `is_active`) VALUES
(1, 1, 'Sosy', 0, 10, 1);
