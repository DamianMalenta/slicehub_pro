
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_stock_levels`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 31, 2026 at 06:48 AM
--

CREATE TABLE `sh_stock_levels` (
  `id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,3) NOT NULL DEFAULT 0.000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_stock_levels`:
--   `warehouse_id`
--       `sh_warehouses` -> `id`
--   `product_id`
--       `sh_products` -> `id`
--

--
-- Zrzut danych tabeli `sh_stock_levels`
--

INSERT INTO `sh_stock_levels` (`id`, `warehouse_id`, `product_id`, `quantity`) VALUES
(1, 1, 2, 100.000),
(2, 1, 1, 200.000),
(3, 1, 4, 5.000),
(4, 2, 1, -57.584),
(5, 2, 2, -31.682),
(6, 2, 3, -40.638),
(7, 2, 4, -17.089);
