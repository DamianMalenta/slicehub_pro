
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_products`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 26, 2026 at 11:20 PM
--

CREATE TABLE `sh_products` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `sku` varchar(50) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'szt',
  `vat_rate` decimal(5,2) NOT NULL DEFAULT 23.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_products`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--

--
-- Zrzut danych tabeli `sh_products`
--

INSERT INTO `sh_products` (`id`, `tenant_id`, `sku`, `name`, `unit`, `vat_rate`, `is_active`) VALUES
(1, 1, 'SKU-001', 'Mąka Typ 00', 'kg', 0.00, 1),
(2, 1, 'SKU-002', 'Ser Mozzarella', 'kg', 5.00, 1),
(3, 1, 'SKU-003', 'Sos Pomidorowy Mutti', 'litr', 8.00, 1),
(4, 1, 'PROD-004', 'Szynka Cotto', 'kg', 5.00, 1);
