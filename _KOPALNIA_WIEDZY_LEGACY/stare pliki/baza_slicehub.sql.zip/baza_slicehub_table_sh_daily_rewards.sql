
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_daily_rewards`
--
-- Creation: Mar 26, 2026 at 09:05 PM
--

CREATE TABLE `sh_daily_rewards` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `claimed_date` date NOT NULL,
  `coins_won` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_daily_rewards`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `user_id`
--       `sh_users` -> `id`
--
