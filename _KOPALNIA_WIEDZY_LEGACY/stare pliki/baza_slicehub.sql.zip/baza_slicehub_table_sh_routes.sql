
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_routes`
--
-- Creation: Mar 29, 2026 at 11:28 PM
-- Ostatnia aktualizacja: Mar 29, 2026 at 11:28 PM
--

CREATE TABLE `sh_routes` (
  `id` int(11) NOT NULL,
  `route_label` varchar(10) DEFAULT NULL,
  `tenant_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
  `start_time` datetime NOT NULL DEFAULT current_timestamp(),
  `end_time` datetime DEFAULT NULL,
  `route_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACJE DLA TABELI `sh_routes`:
--

--
-- Zrzut danych tabeli `sh_routes`
--

INSERT INTO `sh_routes` (`id`, `route_label`, `tenant_id`, `driver_id`, `status`, `start_time`, `end_time`, `route_notes`) VALUES
(1, NULL, 1, 1, 'completed', '2026-03-30 00:09:43', '2026-03-30 00:10:45', NULL),
(2, NULL, 1, 1, 'active', '2026-03-30 00:11:18', NULL, NULL),
(3, NULL, 1, 1, 'active', '2026-03-30 01:09:20', NULL, NULL);
