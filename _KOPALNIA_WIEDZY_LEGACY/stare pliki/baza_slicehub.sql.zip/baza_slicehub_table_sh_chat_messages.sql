
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_chat_messages`
--
-- Creation: Mar 26, 2026 at 09:05 PM
--

CREATE TABLE `sh_chat_messages` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `room_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_chat_messages`:
--   `room_id`
--       `sh_chat_rooms` -> `id`
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `user_id`
--       `sh_users` -> `id`
--
