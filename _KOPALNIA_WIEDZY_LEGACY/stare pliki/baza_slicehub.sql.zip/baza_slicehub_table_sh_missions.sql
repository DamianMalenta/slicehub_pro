
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_missions`
--
-- Creation: Mar 26, 2026 at 08:19 PM
--

CREATE TABLE `sh_missions` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reward_amount` decimal(10,2) DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_missions`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--
