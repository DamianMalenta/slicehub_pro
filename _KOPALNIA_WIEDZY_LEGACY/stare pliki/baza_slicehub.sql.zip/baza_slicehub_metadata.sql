
--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `sh_categories`
--
ALTER TABLE `sh_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_chat_messages`
--
ALTER TABLE `sh_chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_chat_msg_tenant` (`tenant_id`),
  ADD KEY `fk_chat_msg_room` (`room_id`),
  ADD KEY `fk_chat_msg_user` (`user_id`);

--
-- Indeksy dla tabeli `sh_chat_rooms`
--
ALTER TABLE `sh_chat_rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_chat_room_tenant` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_customers`
--
ALTER TABLE `sh_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_tenant_phone` (`tenant_id`,`phone`);

--
-- Indeksy dla tabeli `sh_customer_addresses`
--
ALTER TABLE `sh_customer_addresses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_cust_addr` (`customer_id`,`address`);

--
-- Indeksy dla tabeli `sh_daily_rewards`
--
ALTER TABLE `sh_daily_rewards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_daily_rewards_tenant` (`tenant_id`),
  ADD KEY `fk_daily_rewards_user` (`user_id`);

--
-- Indeksy dla tabeli `sh_deductions`
--
ALTER TABLE `sh_deductions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeksy dla tabeli `sh_drivers`
--
ALTER TABLE `sh_drivers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_driver_user` (`user_id`);

--
-- Indeksy dla tabeli `sh_finance_requests`
--
ALTER TABLE `sh_finance_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`),
  ADD KEY `target_user_id` (`target_user_id`),
  ADD KEY `created_by_id` (`created_by_id`);

--
-- Indeksy dla tabeli `sh_inventory_docs`
--
ALTER TABLE `sh_inventory_docs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`),
  ADD KEY `warehouse_id` (`warehouse_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indeksy dla tabeli `sh_inventory_doc_items`
--
ALTER TABLE `sh_inventory_doc_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doc_id` (`doc_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeksy dla tabeli `sh_inventory_logs`
--
ALTER TABLE `sh_inventory_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeksy dla tabeli `sh_item_modifiers`
--
ALTER TABLE `sh_item_modifiers`
  ADD PRIMARY KEY (`item_id`,`group_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indeksy dla tabeli `sh_item_variants`
--
ALTER TABLE `sh_item_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indeksy dla tabeli `sh_menu_items`
--
ALTER TABLE `sh_menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indeksy dla tabeli `sh_menu_tags`
--
ALTER TABLE `sh_menu_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `sh_missions`
--
ALTER TABLE `sh_missions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_mission_proofs`
--
ALTER TABLE `sh_mission_proofs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mission_id` (`mission_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeksy dla tabeli `sh_modifiers`
--
ALTER TABLE `sh_modifiers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indeksy dla tabeli `sh_modifier_groups`
--
ALTER TABLE `sh_modifier_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_orders`
--
ALTER TABLE `sh_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid_api_key` (`uuid`),
  ADD KEY `tenant_id` (`tenant_id`),
  ADD KEY `table_id` (`table_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `fk_order_driver` (`driver_id`),
  ADD KEY `fk_order_route` (`route_id`);

--
-- Indeksy dla tabeli `sh_order_audit`
--
ALTER TABLE `sh_order_audit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeksy dla tabeli `sh_order_items`
--
ALTER TABLE `sh_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `menu_item_id` (`menu_item_id`);

--
-- Indeksy dla tabeli `sh_products`
--
ALTER TABLE `sh_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_product_mapping`
--
ALTER TABLE `sh_product_mapping`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeksy dla tabeli `sh_recipes`
--
ALTER TABLE `sh_recipes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_item_id` (`menu_item_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeksy dla tabeli `sh_routes`
--
ALTER TABLE `sh_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indeksy dla tabeli `sh_schedule`
--
ALTER TABLE `sh_schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_schedule_tenant` (`tenant_id`),
  ADD KEY `fk_schedule_user` (`user_id`);

--
-- Indeksy dla tabeli `sh_stock_levels`
--
ALTER TABLE `sh_stock_levels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_stock` (`warehouse_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeksy dla tabeli `sh_tables`
--
ALTER TABLE `sh_tables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_taxes`
--
ALTER TABLE `sh_taxes`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `sh_tenants`
--
ALTER TABLE `sh_tenants`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `sh_users`
--
ALTER TABLE `sh_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_warehouses`
--
ALTER TABLE `sh_warehouses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indeksy dla tabeli `sh_work_sessions`
--
ALTER TABLE `sh_work_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_work_sess_tenant` (`tenant_id`),
  ADD KEY `fk_work_sess_user` (`user_id`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `sh_categories`
--
ALTER TABLE `sh_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `sh_chat_messages`
--
ALTER TABLE `sh_chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_chat_rooms`
--
ALTER TABLE `sh_chat_rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `sh_customers`
--
ALTER TABLE `sh_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_customer_addresses`
--
ALTER TABLE `sh_customer_addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_daily_rewards`
--
ALTER TABLE `sh_daily_rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_deductions`
--
ALTER TABLE `sh_deductions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_drivers`
--
ALTER TABLE `sh_drivers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `sh_finance_requests`
--
ALTER TABLE `sh_finance_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_inventory_docs`
--
ALTER TABLE `sh_inventory_docs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT dla tabeli `sh_inventory_doc_items`
--
ALTER TABLE `sh_inventory_doc_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `sh_inventory_logs`
--
ALTER TABLE `sh_inventory_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1192;

--
-- AUTO_INCREMENT dla tabeli `sh_item_variants`
--
ALTER TABLE `sh_item_variants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `sh_menu_items`
--
ALTER TABLE `sh_menu_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT dla tabeli `sh_menu_tags`
--
ALTER TABLE `sh_menu_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_missions`
--
ALTER TABLE `sh_missions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_mission_proofs`
--
ALTER TABLE `sh_mission_proofs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_modifiers`
--
ALTER TABLE `sh_modifiers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `sh_modifier_groups`
--
ALTER TABLE `sh_modifier_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `sh_orders`
--
ALTER TABLE `sh_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;

--
-- AUTO_INCREMENT dla tabeli `sh_order_audit`
--
ALTER TABLE `sh_order_audit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `sh_order_items`
--
ALTER TABLE `sh_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=300;

--
-- AUTO_INCREMENT dla tabeli `sh_products`
--
ALTER TABLE `sh_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `sh_product_mapping`
--
ALTER TABLE `sh_product_mapping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `sh_recipes`
--
ALTER TABLE `sh_recipes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT dla tabeli `sh_routes`
--
ALTER TABLE `sh_routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `sh_schedule`
--
ALTER TABLE `sh_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `sh_stock_levels`
--
ALTER TABLE `sh_stock_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `sh_tables`
--
ALTER TABLE `sh_tables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `sh_taxes`
--
ALTER TABLE `sh_taxes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `sh_tenants`
--
ALTER TABLE `sh_tenants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `sh_users`
--
ALTER TABLE `sh_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT dla tabeli `sh_warehouses`
--
ALTER TABLE `sh_warehouses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `sh_work_sessions`
--
ALTER TABLE `sh_work_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `sh_categories`
--
ALTER TABLE `sh_categories`
  ADD CONSTRAINT `sh_categories_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_chat_messages`
--
ALTER TABLE `sh_chat_messages`
  ADD CONSTRAINT `fk_chat_msg_room` FOREIGN KEY (`room_id`) REFERENCES `sh_chat_rooms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_chat_msg_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_chat_msg_user` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_chat_rooms`
--
ALTER TABLE `sh_chat_rooms`
  ADD CONSTRAINT `fk_chat_room_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_daily_rewards`
--
ALTER TABLE `sh_daily_rewards`
  ADD CONSTRAINT `fk_daily_rewards_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_daily_rewards_user` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_deductions`
--
ALTER TABLE `sh_deductions`
  ADD CONSTRAINT `sh_deductions_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_deductions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_drivers`
--
ALTER TABLE `sh_drivers`
  ADD CONSTRAINT `sh_drivers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_finance_requests`
--
ALTER TABLE `sh_finance_requests`
  ADD CONSTRAINT `sh_finance_requests_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_finance_requests_ibfk_2` FOREIGN KEY (`target_user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_finance_requests_ibfk_3` FOREIGN KEY (`created_by_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_inventory_docs`
--
ALTER TABLE `sh_inventory_docs`
  ADD CONSTRAINT `sh_inventory_docs_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_inventory_docs_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `sh_warehouses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_inventory_docs_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `sh_users` (`id`) ON DELETE SET NULL;

--
-- Ograniczenia dla tabeli `sh_inventory_doc_items`
--
ALTER TABLE `sh_inventory_doc_items`
  ADD CONSTRAINT `sh_inventory_doc_items_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `sh_inventory_docs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_inventory_doc_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `sh_products` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_inventory_logs`
--
ALTER TABLE `sh_inventory_logs`
  ADD CONSTRAINT `sh_inventory_logs_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `sh_products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_inventory_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_item_modifiers`
--
ALTER TABLE `sh_item_modifiers`
  ADD CONSTRAINT `sh_item_modifiers_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `sh_menu_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_item_modifiers_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `sh_modifier_groups` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_item_variants`
--
ALTER TABLE `sh_item_variants`
  ADD CONSTRAINT `sh_item_variants_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `sh_menu_items` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_menu_items`
--
ALTER TABLE `sh_menu_items`
  ADD CONSTRAINT `sh_menu_items_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_menu_items_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `sh_categories` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_missions`
--
ALTER TABLE `sh_missions`
  ADD CONSTRAINT `sh_missions_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_mission_proofs`
--
ALTER TABLE `sh_mission_proofs`
  ADD CONSTRAINT `sh_mission_proofs_ibfk_1` FOREIGN KEY (`mission_id`) REFERENCES `sh_missions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_mission_proofs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_modifiers`
--
ALTER TABLE `sh_modifiers`
  ADD CONSTRAINT `sh_modifiers_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `sh_modifier_groups` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_modifier_groups`
--
ALTER TABLE `sh_modifier_groups`
  ADD CONSTRAINT `sh_modifier_groups_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_orders`
--
ALTER TABLE `sh_orders`
  ADD CONSTRAINT `fk_order_driver` FOREIGN KEY (`driver_id`) REFERENCES `sh_users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_order_route` FOREIGN KEY (`route_id`) REFERENCES `sh_routes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `sh_orders_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_orders_ibfk_2` FOREIGN KEY (`table_id`) REFERENCES `sh_tables` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `sh_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `sh_users` (`id`) ON DELETE SET NULL;

--
-- Ograniczenia dla tabeli `sh_order_audit`
--
ALTER TABLE `sh_order_audit`
  ADD CONSTRAINT `sh_order_audit_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `sh_orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_order_audit_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_order_items`
--
ALTER TABLE `sh_order_items`
  ADD CONSTRAINT `sh_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `sh_orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_order_items_ibfk_2` FOREIGN KEY (`menu_item_id`) REFERENCES `sh_menu_items` (`id`) ON DELETE SET NULL;

--
-- Ograniczenia dla tabeli `sh_products`
--
ALTER TABLE `sh_products`
  ADD CONSTRAINT `sh_products_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_product_mapping`
--
ALTER TABLE `sh_product_mapping`
  ADD CONSTRAINT `sh_product_mapping_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_product_mapping_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `sh_products` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_recipes`
--
ALTER TABLE `sh_recipes`
  ADD CONSTRAINT `sh_recipes_ibfk_1` FOREIGN KEY (`menu_item_id`) REFERENCES `sh_menu_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_recipes_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `sh_products` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_schedule`
--
ALTER TABLE `sh_schedule`
  ADD CONSTRAINT `fk_schedule_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_schedule_user` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_stock_levels`
--
ALTER TABLE `sh_stock_levels`
  ADD CONSTRAINT `sh_stock_levels_ibfk_1` FOREIGN KEY (`warehouse_id`) REFERENCES `sh_warehouses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sh_stock_levels_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `sh_products` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_tables`
--
ALTER TABLE `sh_tables`
  ADD CONSTRAINT `sh_tables_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_users`
--
ALTER TABLE `sh_users`
  ADD CONSTRAINT `sh_users_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_warehouses`
--
ALTER TABLE `sh_warehouses`
  ADD CONSTRAINT `sh_warehouses_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE;

--
-- Ograniczenia dla tabeli `sh_work_sessions`
--
ALTER TABLE `sh_work_sessions`
  ADD CONSTRAINT `fk_work_sess_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `sh_tenants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_work_sess_user` FOREIGN KEY (`user_id`) REFERENCES `sh_users` (`id`) ON DELETE CASCADE;


--
-- Metadane
--
USE `phpmyadmin`;

--
-- Metadane dla tabeli sh_categories
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_chat_messages
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_chat_rooms
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_customers
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_customer_addresses
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_daily_rewards
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_deductions
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_drivers
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_finance_requests
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_inventory_docs
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_inventory_doc_items
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_inventory_logs
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_item_modifiers
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_item_variants
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_menu_items
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_menu_tags
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_missions
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_mission_proofs
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_modifiers
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_modifier_groups
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_orders
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_order_audit
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_order_items
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_products
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_product_mapping
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_recipes
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_routes
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_schedule
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_stock_levels
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_tables
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_taxes
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_tenants
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_users
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_warehouses
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla tabeli sh_work_sessions
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__column_info: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__column_info`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__table_uiprefs: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__table_uiprefs`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__tracking: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__tracking`

--
-- Metadane dla Bazy danych baza_slicehub
--
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__bookmark: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__bookmark`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__relation: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__relation`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__savedsearches: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__savedsearches`
-- Błąd odczytu danych dla tabeli phpmyadmin.pma__central_columns: #1142 - SELECT command denied to user &#039;damian_admin&#039;@&#039;localhost&#039; for table `phpmyadmin`.`pma__central_columns`
