
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_order_audit`
--
-- Creation: Mar 26, 2026 at 08:19 PM
-- Ostatnia aktualizacja: Mar 30, 2026 at 08:59 PM
--

CREATE TABLE `sh_order_audit` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(50) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `new_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_order_audit`:
--   `order_id`
--       `sh_orders` -> `id`
--   `user_id`
--       `sh_users` -> `id`
--
