
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_inventory_doc_items`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 27, 2026 at 12:22 AM
--

CREATE TABLE `sh_inventory_doc_items` (
  `id` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,3) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Cena zakupu'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_inventory_doc_items`:
--   `doc_id`
--       `sh_inventory_docs` -> `id`
--   `product_id`
--       `sh_products` -> `id`
--

--
-- Zrzut danych tabeli `sh_inventory_doc_items`
--

INSERT INTO `sh_inventory_doc_items` (`id`, `doc_id`, `product_id`, `quantity`, `unit_price`) VALUES
(1, 1, 2, 100.000, 0.00),
(2, 1, 1, 200.000, 0.00),
(6, 5, 4, 5.000, 0.00);
