
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_users`
--
-- Creation: Mar 30, 2026 at 08:59 PM
-- Ostatnia aktualizacja: Mar 31, 2026 at 09:27 PM
--

CREATE TABLE `sh_users` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pin_code` varchar(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `password_hash` varchar(255) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `role` enum('admin','manager','waiter','kitchen','driver') CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'waiter',
  `position` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slice_coins` int(11) NOT NULL DEFAULT 0,
  `avatar_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `phone` varchar(20) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `pin` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_users`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--

--
-- Zrzut danych tabeli `sh_users`
--

INSERT INTO `sh_users` (`id`, `tenant_id`, `username`, `first_name`, `last_name`, `pin_code`, `password_hash`, `role`, `position`, `slice_coins`, `avatar_path`, `hourly_rate`, `phone`, `last_seen`, `is_active`, `pin`) VALUES
(3, 1, 'Boss', NULL, NULL, NULL, '$2y$10$flAG58GzP5z/w6rX1bvNj.VD/3BVlR79ml62QFIR.jICC5QhUCUSG', 'waiter', NULL, 0, NULL, 0.00, NULL, '2026-03-31 21:27:57', 1, '1122'),
(4, 1, 'Manager1', NULL, NULL, NULL, '$2y$10$7R.x/k7W8YwKkFpD/XpBnuXyB.fV5B5K5K5K5K5K5K5K5K5K5K5K', 'manager', NULL, 0, NULL, 0.00, NULL, NULL, 1, '4444'),
(5, 1, 'Kelner1', NULL, NULL, NULL, '$2y$10$7R.x/k7W8YwKkFpD/XpBnuXyB.fV5B5K5K5K5K5K5K5K5K5K5K5K', 'waiter', NULL, 0, NULL, 0.00, NULL, NULL, 1, '2222'),
(6, 1, 'Kierowca1', NULL, NULL, NULL, '$2y$10$7R.x/k7W8YwKkFpD/XpBnuXyB.fV5B5K5K5K5K5K5K5K5K5K5K5K', 'driver', NULL, 0, NULL, 0.00, NULL, NULL, 1, '1111'),
(7, 1, 'Kucharz1', NULL, NULL, NULL, '$2y$10$7R.x/k7W8YwKkFpD/XpBnuXyB.fV5B5K5K5K5K5K5K5K5K5K5K5K', 'waiter', NULL, 0, NULL, 0.00, NULL, NULL, 1, '3333');
