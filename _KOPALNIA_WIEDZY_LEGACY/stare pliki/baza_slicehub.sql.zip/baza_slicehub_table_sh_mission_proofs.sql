
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_mission_proofs`
--
-- Creation: Mar 26, 2026 at 08:19 PM
--

CREATE TABLE `sh_mission_proofs` (
  `id` int(11) NOT NULL,
  `mission_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_mission_proofs`:
--   `mission_id`
--       `sh_missions` -> `id`
--   `user_id`
--       `sh_users` -> `id`
--
