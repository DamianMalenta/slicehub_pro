
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_customer_addresses`
--
-- Creation: Mar 29, 2026 at 08:23 PM
--

CREATE TABLE `sh_customer_addresses` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `usage_count` int(11) DEFAULT 1,
  `last_used` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- RELACJE DLA TABELI `sh_customer_addresses`:
--
