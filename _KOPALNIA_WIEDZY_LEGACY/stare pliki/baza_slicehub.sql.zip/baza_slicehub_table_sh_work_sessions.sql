
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_work_sessions`
--
-- Creation: Mar 26, 2026 at 09:05 PM
-- Ostatnia aktualizacja: Mar 31, 2026 at 09:26 PM
--

CREATE TABLE `sh_work_sessions` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `total_time` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_work_sessions`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `user_id`
--       `sh_users` -> `id`
--

--
-- Zrzut danych tabeli `sh_work_sessions`
--

INSERT INTO `sh_work_sessions` (`id`, `tenant_id`, `user_id`, `start_time`, `end_time`, `total_time`) VALUES
(14, 1, 6, '2026-03-31 00:18:28', NULL, NULL),
(15, 1, 6, '2026-03-31 00:26:44', NULL, NULL),
(16, 1, 6, '2026-03-31 00:57:44', '2026-03-31 01:15:37', 0.28),
(17, 1, 6, '2026-03-31 01:15:56', '2026-03-31 23:26:58', 22.18),
(18, 1, 5, '2026-03-31 01:47:03', NULL, NULL);
