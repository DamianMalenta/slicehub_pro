
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_customers`
--
-- Creation: Mar 29, 2026 at 08:23 PM
--

CREATE TABLE `sh_customers` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- RELACJE DLA TABELI `sh_customers`:
--
