
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_tables`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 29, 2026 at 08:34 PM
--

CREATE TABLE `sh_tables` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `table_number` varchar(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `qr_key` varchar(50) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `status` enum('free','occupied','dirty','reserved') CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'free'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_tables`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--

--
-- Zrzut danych tabeli `sh_tables`
--

INSERT INTO `sh_tables` (`id`, `tenant_id`, `table_number`, `qr_key`, `status`) VALUES
(1, 1, '1', 'SH-QR-F4936A3A', 'free'),
(2, 1, '2', 'QR-START-2', 'free'),
(3, 1, '3', 'QR-START-3', 'occupied'),
(4, 1, 'VIP', 'QR-START-4', 'free'),
(5, 1, '4', '', 'free'),
(6, 1, 'kasi', '', 'free');
