
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_item_modifiers`
--
-- Creation: Mar 31, 2026 at 03:38 AM
--

CREATE TABLE `sh_item_modifiers` (
  `item_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACJE DLA TABELI `sh_item_modifiers`:
--   `item_id`
--       `sh_menu_items` -> `id`
--   `group_id`
--       `sh_modifier_groups` -> `id`
--
