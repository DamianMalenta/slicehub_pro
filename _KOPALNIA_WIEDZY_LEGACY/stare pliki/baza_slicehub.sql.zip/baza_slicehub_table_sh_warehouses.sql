
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_warehouses`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 26, 2026 at 07:47 PM
--

CREATE TABLE `sh_warehouses` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_warehouses`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--

--
-- Zrzut danych tabeli `sh_warehouses`
--

INSERT INTO `sh_warehouses` (`id`, `tenant_id`, `name`) VALUES
(1, 1, 'Magazyn Główny'),
(2, 1, 'Kuchnia / Bar');
