
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_item_variants`
--
-- Creation: Mar 31, 2026 at 02:49 AM
-- Ostatnia aktualizacja: Mar 31, 2026 at 09:40 PM
--

CREATE TABLE `sh_item_variants` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ascii_key` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `display_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACJE DLA TABELI `sh_item_variants`:
--   `item_id`
--       `sh_menu_items` -> `id`
--

--
-- Zrzut danych tabeli `sh_item_variants`
--

INSERT INTO `sh_item_variants` (`id`, `item_id`, `name`, `ascii_key`, `price`, `is_active`, `display_order`) VALUES
(6, 1, '37 CM', 'EXISTING', 38.00, 1, 0),
(7, 1, '30 CM', 'EXISTING', 31.00, 1, 0),
(9, 14, 'MALA PORCJA', 'VAR_NEW', 18.00, 1, 0),
(10, 2, 'Nowy', 'VAR_AUTO', 0.00, 1, 0);
