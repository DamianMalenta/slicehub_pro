
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_tenants`
--
-- Creation: Mar 26, 2026 at 08:19 PM
-- Ostatnia aktualizacja: Mar 26, 2026 at 08:19 PM
--

CREATE TABLE `sh_tenants` (
  `id` int(11) NOT NULL,
  `nip` varchar(20) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `primary_color` varchar(7) CHARACTER SET ascii COLLATE ascii_bin DEFAULT '#e63946',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_tenants`:
--

--
-- Zrzut danych tabeli `sh_tenants`
--

INSERT INTO `sh_tenants` (`id`, `nip`, `name`, `primary_color`, `created_at`) VALUES
(1, '1112223344', 'Główna Pizzeria', '#e63946', '2026-03-26 19:47:20');
