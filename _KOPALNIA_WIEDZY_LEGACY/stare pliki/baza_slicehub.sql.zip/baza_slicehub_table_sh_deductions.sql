
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_deductions`
--
-- Creation: Mar 26, 2026 at 08:19 PM
--

CREATE TABLE `sh_deductions` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` enum('advance','bonus','meal') CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected') CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'pending',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_deductions`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `user_id`
--       `sh_users` -> `id`
--
