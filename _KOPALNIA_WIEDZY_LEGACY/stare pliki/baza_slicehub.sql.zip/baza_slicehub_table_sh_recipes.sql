
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_recipes`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 26, 2026 at 11:26 PM
--

CREATE TABLE `sh_recipes` (
  `id` int(11) NOT NULL,
  `menu_item_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,3) NOT NULL,
  `waste_percent` decimal(5,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_recipes`:
--   `menu_item_id`
--       `sh_menu_items` -> `id`
--   `product_id`
--       `sh_products` -> `id`
--

--
-- Zrzut danych tabeli `sh_recipes`
--

INSERT INTO `sh_recipes` (`id`, `menu_item_id`, `product_id`, `quantity`, `waste_percent`) VALUES
(7, 2, 1, 0.260, 5.00),
(8, 2, 2, 0.150, 5.00),
(9, 2, 4, 0.150, 5.00),
(10, 2, 3, 0.200, 5.00),
(11, 1, 1, 0.260, 5.00),
(12, 1, 2, 0.150, 5.00),
(13, 1, 3, 0.150, 5.00);
