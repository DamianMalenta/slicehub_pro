
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_drivers`
--
-- Creation: Mar 27, 2026 at 09:59 PM
-- Ostatnia aktualizacja: Mar 31, 2026 at 09:26 PM
--

CREATE TABLE `sh_drivers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('available','busy','offline') CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'offline',
  `initial_cash` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_drivers`:
--   `user_id`
--       `sh_users` -> `id`
--

--
-- Zrzut danych tabeli `sh_drivers`
--

INSERT INTO `sh_drivers` (`id`, `user_id`, `status`, `initial_cash`) VALUES
(2, 6, 'offline', 0.00),
(3, 5, 'available', 0.00);
