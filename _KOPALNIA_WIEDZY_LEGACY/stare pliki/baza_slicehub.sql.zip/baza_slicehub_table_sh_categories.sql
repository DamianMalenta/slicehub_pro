
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_categories`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 31, 2026 at 03:11 AM
--

CREATE TABLE `sh_categories` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ascii_key` varchar(50) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `is_menu` tinyint(1) NOT NULL DEFAULT 1,
  `display_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_categories`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--

--
-- Zrzut danych tabeli `sh_categories`
--

INSERT INTO `sh_categories` (`id`, `tenant_id`, `name`, `ascii_key`, `is_menu`, `display_order`) VALUES
(1, 1, 'Pizze', 'CAT_PIZZA', 1, 0),
(2, 1, 'Napoje', 'CAT_DRINKS', 1, 0),
(3, 1, '🍕 Pizze TEST', 'CAT_PIZZA_TEST', 1, 90),
(4, 1, '🍔 Burgery TEST', 'CAT_BURGER_TEST', 1, 91),
(5, 1, '🥤 Napoje TEST', 'CAT_DRINK_TEST', 1, 92),
(6, 1, 'MAKARONY', 'CAT_MAKARONY', 1, 93);
