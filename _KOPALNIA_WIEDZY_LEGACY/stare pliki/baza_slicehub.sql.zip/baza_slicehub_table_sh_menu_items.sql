
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_menu_items`
--
-- Creation: Mar 31, 2026 at 07:53 AM
-- Ostatnia aktualizacja: Mar 31, 2026 at 07:53 AM
--

CREATE TABLE `sh_menu_items` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ascii_key` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `vat_rate` decimal(5,2) NOT NULL DEFAULT 8.00,
  `type` enum('standard','half_half','modifier') CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'standard',
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `vat_id` int(11) DEFAULT 1,
  `vat_takeaway_id` int(11) DEFAULT 1,
  `plu_code` varchar(20) DEFAULT NULL,
  `printer_group` varchar(50) DEFAULT 'KITCHEN_1',
  `prep_time` int(11) DEFAULT 15,
  `priority` int(11) DEFAULT 1,
  `unit` varchar(10) DEFAULT 'szt',
  `is_weighted` tinyint(1) DEFAULT 0,
  `tags` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `available_start` time DEFAULT NULL,
  `available_end` time DEFAULT NULL,
  `available_days` varchar(20) DEFAULT '1,2,3,4,5,6,7',
  `stock_count` int(11) DEFAULT -1,
  `badge_type` enum('none','new','promo','bestseller','hot') DEFAULT 'none',
  `is_secret` tinyint(1) DEFAULT 0,
  `video_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_menu_items`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `category_id`
--       `sh_categories` -> `id`
--

--
-- Zrzut danych tabeli `sh_menu_items`
--

INSERT INTO `sh_menu_items` (`id`, `tenant_id`, `category_id`, `name`, `ascii_key`, `is_active`, `price`, `vat_rate`, `type`, `is_deleted`, `vat_id`, `vat_takeaway_id`, `plu_code`, `printer_group`, `prep_time`, `priority`, `unit`, `is_weighted`, `tags`, `description`, `display_order`, `available_start`, `available_end`, `available_days`, `stock_count`, `badge_type`, `is_secret`, `video_url`) VALUES
(1, 1, 1, 'Margherita', 'ITM_MARGHERITA', 1, 29.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(2, 1, 1, 'Capricciosa 32cm', 'ITM_CAPRICCDFIOSA_32CM', 0, 34.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(3, 1, 1, 'PIZZA PÓŁ NA PÓŁ', NULL, 1, 0.00, 8.00, 'half_half', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(4, 1, 3, 'Margherita Baza TEST', NULL, 1, 25.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(5, 1, 3, 'Pepperoni Ostra (Wymaga 86) TEST', NULL, 1, 32.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(6, 1, 3, 'Wege Premium (Dużo składników) TEST', NULL, 1, 35.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(7, 1, 3, 'Pół na Pół (Kreator) TEST', NULL, 1, 0.00, 8.00, 'half_half', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(8, 1, 4, 'Classic Beef (Kuchnia) TEST', NULL, 1, 28.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(9, 1, 4, 'Drwal BBQ (Kuchnia) TEST', NULL, 1, 36.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(10, 1, 4, 'Vege Burger (Wege) TEST', NULL, 1, 30.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(11, 1, 5, 'Cola 0.5L (VAT 23%) TEST', NULL, 1, 8.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(12, 1, 5, 'Woda Gazowana (VAT 23%) TEST', NULL, 1, 6.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(13, 1, 5, 'Sok Tłoczony (VAT 8%) TEST', NULL, 1, 12.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL),
(14, 1, 6, 'Spaghetti', 'ITM_SPAGHETTI', 0, 0.00, 8.00, 'standard', 0, 1, 1, NULL, 'KITCHEN_1', 15, 1, 'szt', 0, NULL, NULL, 0, NULL, NULL, '1,2,3,4,5,6,7', -1, 'none', 0, NULL);
