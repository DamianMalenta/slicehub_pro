
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_chat_rooms`
--
-- Creation: Mar 26, 2026 at 09:05 PM
-- Ostatnia aktualizacja: Mar 26, 2026 at 09:05 PM
--

CREATE TABLE `sh_chat_rooms` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `display_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET ascii COLLATE ascii_bin DEFAULT 'fa-hashtag'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_chat_rooms`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--

--
-- Zrzut danych tabeli `sh_chat_rooms`
--

INSERT INTO `sh_chat_rooms` (`id`, `tenant_id`, `display_name`, `icon`) VALUES
(1, 1, 'Główny', 'fa-fire'),
(2, 1, 'Kuchnia', 'fa-utensils'),
(3, 1, 'Kierowcy', 'fa-car');
