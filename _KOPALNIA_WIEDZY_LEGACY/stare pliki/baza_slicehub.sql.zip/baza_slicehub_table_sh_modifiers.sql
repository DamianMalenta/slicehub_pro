
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_modifiers`
--
-- Creation: Mar 31, 2026 at 03:38 AM
-- Ostatnia aktualizacja: Mar 31, 2026 at 04:01 AM
--

CREATE TABLE `sh_modifiers` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELACJE DLA TABELI `sh_modifiers`:
--   `group_id`
--       `sh_modifier_groups` -> `id`
--

--
-- Zrzut danych tabeli `sh_modifiers`
--

INSERT INTO `sh_modifiers` (`id`, `group_id`, `name`, `price`, `is_active`) VALUES
(1, 1, 'sos czosnkowy', 3.50, 1);
