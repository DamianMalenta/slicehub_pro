
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sh_inventory_docs`
--
-- Creation: Mar 26, 2026 at 07:47 PM
-- Ostatnia aktualizacja: Mar 30, 2026 at 08:59 PM
--

CREATE TABLE `sh_inventory_docs` (
  `id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `doc_number` varchar(50) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `doc_type` enum('PZ','WZ','RW','IN') CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `supplier_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_invoice_number` varchar(50) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELACJE DLA TABELI `sh_inventory_docs`:
--   `tenant_id`
--       `sh_tenants` -> `id`
--   `warehouse_id`
--       `sh_warehouses` -> `id`
--   `created_by`
--       `sh_users` -> `id`
--

--
-- Zrzut danych tabeli `sh_inventory_docs`
--

INSERT INTO `sh_inventory_docs` (`id`, `tenant_id`, `warehouse_id`, `doc_number`, `doc_type`, `supplier_name`, `supplier_invoice_number`, `created_by`, `created_at`) VALUES
(1, 1, 1, 'fv/12/12/435', 'PZ', '', NULL, NULL, '2026-03-26 21:50:10'),
(5, 1, 1, 'fv/4434/6656/6', 'PZ', 'sde', NULL, NULL, '2026-03-27 00:22:08');
